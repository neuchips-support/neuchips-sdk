import os

if os.name == 'nt':
    neudm_dll_dir = os.path.abspath(os.path.dirname(__file__))
    try:
        os.add_dll_directory(neudm_dll_dir)
    except Exception:
        pass
    del neudm_dll_dir
