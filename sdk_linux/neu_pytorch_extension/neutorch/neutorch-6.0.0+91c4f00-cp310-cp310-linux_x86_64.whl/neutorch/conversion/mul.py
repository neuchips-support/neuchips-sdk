import torch
from torch import Tensor
import torch.nn as nn
import torch.fx.experimental.optimization as optimization
import torch.fx as fx
import copy
import operator


# replace torch linear with neuchips linear during inference
def matmul_conversion(model: nn.Module, inplace=False) -> nn.Module:
    if not inplace:
        model = copy.deepcopy(model)
    fx_model = fx.symbolic_trace(model)

    patterns = set([operator.mul, torch.mul, "mul"])
    # Go through all the nodes in the Graph
    for n in fx_model.graph.nodes:
        # If the target matches one of the patterns
        if any(n.target == pattern for pattern in patterns):
            # Set the insert point, add the new node, and replace all uses
            # of `n` with the new node
            with fx_model.graph.inserting_after(n):
                new_node = fx_model.graph.call_function(
                    torch.ops.neu.mul, n.args, n.kwargs)
                n.replace_all_uses_with(new_node)
            # Remove the old node from the graph
            fx_model.graph.erase_node(n)

    # Don't forget to recompile!
    fx_model.recompile()

    return fx_model
