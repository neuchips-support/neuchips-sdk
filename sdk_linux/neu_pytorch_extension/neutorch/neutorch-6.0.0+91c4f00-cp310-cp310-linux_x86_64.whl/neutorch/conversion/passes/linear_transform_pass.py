import torch
from torch import nn
from neutorch.conversion.passes.neu_linear import neu_linear


def linear_transform_pass(
    model: nn.Module,
    force_full_traversal: bool = False
) -> tuple[nn.Module, bool]:
    """
    Replace torch.nn.Linear with neu_linear for inference.

    If force_full_traversal is False, only traverse model.model.layers and model.lm_head (if present).
    If force_full_traversal is True, traverse the entire model recursively.

    Returns:
        (nn.Module, bool): The transformed model and whether any replacement occurred.
    """

    def replace_linear(model: nn.Module) -> bool:
        replaced_any = False
        for n, child_module in model.named_children():
            if len(list(child_module.children())) > 0:
                # compound module, go inside it
                if replace_linear(child_module):
                    replaced_any = True

            if isinstance(child_module, torch.nn.Linear):
                _neu_linear = neu_linear(weight=child_module.weight, bias=child_module.bias)
                setattr(model, n, _neu_linear)
                replaced_any = True
        return replaced_any

    def replace_causallm(model: nn.Module) -> bool:
        replaced_any = False
        if hasattr(model, "model") and hasattr(model.model, "layers"):
            for layer in model.model.layers:
                if replace_linear(layer):
                    replaced_any = True

        if hasattr(model, "lm_head") and isinstance(model.lm_head, torch.nn.Linear):
            _neu_linear = neu_linear(weight=model.lm_head.weight, bias=model.lm_head.bias)
            setattr(model, "lm_head", _neu_linear)
            replaced_any = True
        return replaced_any

    replaced = False
    if force_full_traversal:
        replaced = replace_linear(model)
    else:
        replaced = replace_causallm(model)

    return model, replaced
