#
# NEUCHIPS CONFIDENTIAL
#
# Copyright (C) 2018-2022 NEUCHIPS Corp.
# All Rights Reserved.
# Author: Ethan Chen <ethan_chen@neuchips.ai>
#
# The information and source code contained herein is the exclusive property
# of NEUCHIPS CORPORATION and may not be disclosed, examined or reproduced
# in whole or in part without explicit written authorization from the company.
#

import torch.nn as nn
import copy
from neutorch.conversion.passes.linear_transform_pass import linear_transform_pass
from neutorch.conversion.passes.qkv_linear_merge_pass import qkv_linear_merge_pass
from neutorch.conversion.passes.gate_up_linear_merge_pass import (
    gate_up_linear_merge_pass,
)
from neutorch.conversion.passes.low_rank_decomposition_pass import (
    low_rank_decomposition_pass,
)

_SUPPORTED_MODELS = [
    "LLaMAForCausalLM",
    "LlamaForCausalLM",
    "MistralForCausalLM",
    "PhiForCausalLM",
    "AutoModelForCausalLM",
    "Phi3ForCausalLM",
    "Gemma2ForCausalLM",
    "Qwen2ForCausalLM",
    "Qwen3ForCausalLM"
]


def is_transfomer_model(model):
    name = model.__class__.__module__
    return name.startswith("transformers.models.")


def is_supported_model(model):
    return model.__class__.__name__ in _SUPPORTED_MODELS


def linear_conversion(
    model_: nn.Module,
    inplace=False,
    merge_qkv=True,
    merge_gate_up=True,
    low_rank_ratio=1.0,
    allow_unsupported_model=False,
) -> tuple[nn.Module, bool]:
    # replace torch linear with neuchips linear for inference
    if not inplace:
        model = copy.deepcopy(model_)
    else:
        model = model_

    conversion = False
    if not is_supported_model(model):
        model_class_name = model.__class__.__name__
        if allow_unsupported_model:
            print(
                f"Warning: Unsupported model {model_class_name} but "
                f"allow_unsupported_model is True. Proceeding with conversion."
            )
        else:
            return model, conversion

    if merge_qkv:
        qkv_linear_merge_pass(model)

    if merge_gate_up:
        gate_up_linear_merge_pass(model)

    if low_rank_ratio < 1.0:
        low_rank_decomposition_pass(model, low_rank_ratio)

    model, conversion = linear_transform_pass(
        model, force_full_traversal=allow_unsupported_model
    )

    return model, conversion
