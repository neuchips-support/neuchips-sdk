import torch
import types
from typing import Dict, Type, List

from transformers import __version__ as transformers_version
from neutorch.conversion.passes.mlp_forwards.gate_up_forward import (
    gate_up_forward,
)

GATE_UP_MERGE_SUPPORTED_TRANSFORMERS_VERSION: List[str] = [
    "4.51.0",
    "4.53.0",
]

GATE_UP_MERGE_SUPPORTED_MODULE_TYPES: Dict[Type[torch.nn.Module], callable] = {}


try:
    from transformers.models.qwen3_moe.modeling_qwen3_moe import Qwen3MoeMLP

    GATE_UP_MERGE_SUPPORTED_MODULE_TYPES[Qwen3MoeMLP] = gate_up_forward
except ImportError:
    pass


def gate_up_linear_merge_pass(model: torch.nn.Module):
    """
    Recursively traverse model.model.layers and attempt
    to merge any submodule that has gate_proj and up_proj.
    """

    def try_merge_gate_up(m: torch.nn.Module):
        for n, module in m.named_children():
            if type(module) in GATE_UP_MERGE_SUPPORTED_MODULE_TYPES:
                if not (hasattr(module, "gate_proj") and hasattr(module, "up_proj")):
                    return
                gate_proj = module.gate_proj
                up_proj = module.up_proj

                if not all(
                    isinstance(x, torch.nn.Linear) for x in [gate_proj, up_proj]
                ):
                    return

                # in_features sizes shoule be the same
                in_features = gate_proj.in_features
                if up_proj.in_features != in_features:
                    return

                out_gate = gate_proj.out_features
                out_up = up_proj.out_features
                total_out = out_gate + out_up

                has_bias = gate_proj.bias is not None

                # Create one merged linear
                gate_up_proj = torch.nn.Linear(
                    in_features, total_out, bias=has_bias
                ).to(dtype=gate_proj.weight.dtype)
                gate_up_proj = gate_up_proj.to(gate_proj.weight.device)

                # Copy weights/bias
                with torch.no_grad():
                    gate_up_proj.weight[:out_gate, :] = gate_proj.weight
                    gate_up_proj.weight[out_gate : out_gate + out_up, :] = (
                        up_proj.weight
                    )

                    if has_bias:
                        gate_up_proj.bias[:out_gate] = gate_proj.bias
                        gate_up_proj.bias[out_gate : out_gate + out_up] = up_proj.bias

                # Delete old modules
                del module.gate_proj
                del module.up_proj

                # Attach the new gate_up_proj
                module.gate_up_proj = gate_up_proj
                module.forward = types.MethodType(
                    GATE_UP_MERGE_SUPPORTED_MODULE_TYPES[type(module)], module
                )

            try_merge_gate_up(module)

    if transformers_version not in GATE_UP_MERGE_SUPPORTED_TRANSFORMERS_VERSION:
        print(
            f"Warning: Unsupported transformers version {transformers_version}. Gate/Up merge may not work as expected."
        )
        return model
    try_merge_gate_up(model)
    return model
