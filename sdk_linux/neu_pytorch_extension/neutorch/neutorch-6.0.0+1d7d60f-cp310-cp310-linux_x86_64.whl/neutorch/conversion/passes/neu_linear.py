import torch
from neutorch._C import MultiDeviceN3KPytorchFacade
from torch import Tensor


def requires_weight_split(weight_shape: torch.Size, max_size: int = 16384) -> bool:
    return weight_shape[1] > max_size and weight_shape[1] <= (max_size * 2)


# Todo
# 1. Design a more dynamic split algorithm to adapt to hardware
# 2. When the matrix size exceeds 32768, split into more than two operations
class neu_linear(torch.nn.Module):
    def __init__(self, weight: Tensor, bias) -> None:
        super().__init__()
        self.facade = MultiDeviceN3KPytorchFacade.get_instance()

        if len(weight.shape) != 2:
            raise ValueError(
                f"Expected 2D weight matrix, got {len(weight.shape)}D tensor."
            )

        if requires_weight_split(weight.shape):
            self.split = True
            mid = weight.shape[1] // 2
            weight1 = weight[:, :mid]
            weight2 = weight[:, mid:]
            self.op_id1 = self.facade.register_matmul_with_weight(weight1.detach().t())
            self.op_id2 = self.facade.register_matmul_with_weight(weight2.detach().t())
        else:
            self.split = False
            self.op_id = self.facade.register_matmul_with_weight(weight.detach().t())

        self.bias = bias
        self.weight = weight
        self.in_features = weight.shape[1]
        self.out_features = weight.shape[0]

    def forward(self, input: Tensor) -> Tensor:
        input_2d = False
        if len(input.shape) == 2:
            input = input.unsqueeze(0)
            input_2d = True

        if len(input.shape) != 3:
            raise ValueError(
                f"Expected 3D input tensor, got {len(input.shape)}D tensor."
            )

        if self.split:
            if input.shape[2] != self.weight.shape[1]:
                raise ValueError(
                    f"Input dim ({input.shape[2]}) doesn't match weight dim ({self.weight.shape[1]}) for splitting."
                )
            mid = input.shape[2] // 2
            input1 = input[:, :, :mid]
            input2 = input[:, :, mid:]
            result1 = self.facade.execute_op(self.op_id1, input1)
            result2 = self.facade.execute_op(self.op_id2, input2)
            if result1 is None or result2 is None:
                raise ValueError("One of the results is None, check matmul operation.")
            if result1.shape[0] != result2.shape[0]:
                raise ValueError(
                    f"Batch size does not match between result1 and result2: {result1.shape[0]} != {result2.shape[0]}"
                )
            result = result1 + result2
        else:
            result = self.facade.execute_op(self.op_id, input)

        if input_2d:
            result = result.squeeze(0)

        if self.bias is not None:
            result = result + self.bias
        return result

    def extra_repr(self) -> str:
        return f"in_features={self.in_features}, out_features={self.out_features}, bias={self.bias is not None}"
