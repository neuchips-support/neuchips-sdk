import torch
import types

from transformers import __version__ as transformers_version

QKV_MERGE_SUPPORTED_TRANSFORMERS_VERSION = [
    "4.43.2",
]

# TODO: Reduce the attention forward functions to one single function
from neutorch.conversion.passes.attention_forwards.llama import llama_attention_forward
from neutorch.conversion.passes.attention_forwards.mistral import mistral_attention_forward
from neutorch.conversion.passes.attention_forwards.gemma2 import gemma2_attention_forward
from neutorch.conversion.passes.attention_forwards.qwen2 import qwen2_attention_forward

from transformers.models.llama.modeling_llama import LlamaAttention
from transformers.models.mistral.modeling_mistral import MistralAttention
from transformers.models.gemma2.modeling_gemma2 import Gemma2Attention
from transformers.models.qwen2.modeling_qwen2 import Qwen2Attention

QKV_MERGE_SUPPORTED_MODULE_TYPES = {
    LlamaAttention: llama_attention_forward,
    MistralAttention: mistral_attention_forward,
    Gemma2Attention: gemma2_attention_forward,
    Qwen2Attention: qwen2_attention_forward,
}

# Attention modules were refactored starting from transformers version 4.48.0.
# For details, see the following commit:
# https://github.com/huggingface/transformers/commit/2c47618c1a282f925446506d53108dc6e82d9ef0
try:
    from transformers.models.llama.modeling_llama import LlamaSdpaAttention
    from transformers.models.mistral.modeling_mistral import MistralSdpaAttention
    from transformers.models.gemma2.modeling_gemma2 import Gemma2SdpaAttention
    from transformers.models.qwen2.modeling_qwen2 import Qwen2SdpaAttention
    from neutorch.conversion.passes.attention_forwards.llama import llama_sdpa_attention_forward
    from neutorch.conversion.passes.attention_forwards.mistral import mistral_sdpa_attention_forward
    from neutorch.conversion.passes.attention_forwards.gemma2 import gemma2_sdpa_attention_forward
    from neutorch.conversion.passes.attention_forwards.qwen2 import qwen2_sdpa_attention_forward

    QKV_MERGE_SUPPORTED_MODULE_TYPES[LlamaSdpaAttention] = llama_sdpa_attention_forward
    QKV_MERGE_SUPPORTED_MODULE_TYPES[MistralSdpaAttention] = mistral_sdpa_attention_forward
    QKV_MERGE_SUPPORTED_MODULE_TYPES[Gemma2SdpaAttention] = gemma2_sdpa_attention_forward
    QKV_MERGE_SUPPORTED_MODULE_TYPES[Qwen2SdpaAttention] = qwen2_sdpa_attention_forward
except ImportError:
    pass

def qkv_linear_merge_pass(model: torch.nn.Module):
    """
    Recursively traverse model.model.layers and attempt
    to merge any submodule that has q_proj, k_proj, v_proj.
    """

    def try_merge_qkv(m: torch.nn.Module):
        for n, module in m.named_children():
            if type(module) in QKV_MERGE_SUPPORTED_MODULE_TYPES:
                if not (
                    hasattr(module, "q_proj")
                    and hasattr(module, "k_proj")
                    and hasattr(module, "v_proj")
                ):
                    return
                q_proj = module.q_proj
                k_proj = module.k_proj
                v_proj = module.v_proj

                if not all(
                    isinstance(x, torch.nn.Linear) for x in [q_proj, k_proj, v_proj]
                ):
                    return

                # in_features sizes shoule be the same
                in_features = q_proj.in_features
                if (
                    k_proj.in_features != in_features
                    or v_proj.in_features != in_features
                ):
                    return

                out_q = q_proj.out_features
                out_k = k_proj.out_features
                out_v = v_proj.out_features
                total_out = out_q + out_k + out_v

                has_bias = q_proj.bias is not None

                # Create one merged linear
                qkv_proj = torch.nn.Linear(in_features, total_out, bias=has_bias).to(
                    dtype=q_proj.weight.dtype
                )
                qkv_proj = qkv_proj.to(q_proj.weight.device)

                # Copy weights/bias
                with torch.no_grad():
                    qkv_proj.weight[:out_q, :] = q_proj.weight
                    qkv_proj.weight[out_q : out_q + out_k, :] = k_proj.weight
                    qkv_proj.weight[out_q + out_k :, :] = v_proj.weight

                    if has_bias:
                        qkv_proj.bias[:out_q] = q_proj.bias
                        qkv_proj.bias[out_q : out_q + out_k] = k_proj.bias
                        qkv_proj.bias[out_q + out_k :] = v_proj.bias

                # Delete old modules
                del module.q_proj
                del module.k_proj
                del module.v_proj

                # Attach the new qkv_proj
                module.qkv_proj = qkv_proj
                module.forward = types.MethodType(
                    QKV_MERGE_SUPPORTED_MODULE_TYPES[type(module)], module
                )

            try_merge_qkv(module)

    if transformers_version not in QKV_MERGE_SUPPORTED_TRANSFORMERS_VERSION:
        print(
            f"Warning: Unsupported transformers version {transformers_version}. QKV merge may not work as expected."
        )
        return model
    try_merge_qkv(model)
    return model
