#
# NEUCHIPS CONFIDENTIAL
#
# Copyright (C) 2018-2023 NEUCHIPS Corp.
# All Rights Reserved.
# Author: Ethan Chen <ethan_chen@neuchips.ai>
#
# The information and source code contained herein is the exclusive property
# of NEUCHIPS CORPORATION and may not be disclosed, examined or reproduced
# in whole or in part without explicit written authorization from the company.
#

import sys
from neutorch.conversion.linear import linear_conversion
from neutorch._C import dtype
from neutorch._C import MultiDeviceN3KPytorchFacade


def low_cpu_mem_usage(enabled: bool):
    facade = MultiDeviceN3KPytorchFacade.get_instance()
    facade.low_cpu_mem_usage(enabled)


def optimize(
    model,
    usage_pattern="general",
    weight_dtype=dtype.ffp8,
    inplace=False,
    config_dir="",
    merge_qkv=True,
    merge_gate_up=True,
    low_rank_ratio=1.0,
    allow_unsupported_model=False,
):
    """
    Args:
        model (torch.nn.Module): User model to apply optimizations on.
        usage_pattern (string): Specifies the user scenario.
                                The value can be either `general` for normal purposes (e.g., chat, QA)
                                or `long` for scenarios like Retrieval-Augmented Generation (RAG),
                                where the average input prompt is longer.
        weight_dtype (neutorch.dtype): Weight quantization data type
        config_dir (string): The directory path where config.json is stored.
        merge_qkv (bool): Whether to merge QKV linears.
        low_rank_ratio (float): Ratio for low-rank decomposition (<1.0 enables).
        allow_unsupported_model (bool): If True, convert all Linear modules regardless of support list.

    Returns:
        Model modified according to the optimizations

    Examples:
        >>> # linear weight quantized to ffp8, others bfloat16 inference case.
        >>> m = LlamaForCausalLM.from_pretrained(...)
        >>> optimized_model = neutorch.optimize(model, weight_dtype=neutorch.ffp8)
        >>> # running inferences ...
    """
    supported_weight_type = [dtype.ffp8, dtype.bf16]
    assert (
        weight_dtype in supported_weight_type
    ), "Not supported weight quant type: " + str(weight_dtype)

    print("Neutorch is optimizing...")
    opt_model, converted = linear_conversion(
        model,
        inplace=inplace,
        merge_qkv=merge_qkv,
        merge_gate_up=merge_gate_up,
        low_rank_ratio=low_rank_ratio,
        allow_unsupported_model=allow_unsupported_model,
    )

    if not converted:
        print("Model is not supported, skipping optimization...")
        print("[INFO] model structure ------------------------------------------------")
        print(model)
        print("[INFO] model structure ------------------------------------------------")
        if not allow_unsupported_model:
            print(
                "*** You can try allow_unsupported_model=True in optimize() to let Neutorch proceed with the optimization. ***"
            )
        return model

    facade = MultiDeviceN3KPytorchFacade.get_instance()

    # For general use, set the max batch size to 256.
    max_batch_size = 256
    if usage_pattern == "long":
        max_batch_size = 512

    try:
        if config_dir:
            facade.load(config_dir)
            facade.execute_code_generation(
                directory=config_dir, max_batch_size=max_batch_size
            )
        else:
            facade.execute_code_generation(max_batch_size=max_batch_size)
    except RuntimeError as e:
        print(f"Error: {e}")
        print("Stopping Neutorch optimization...")
        sys.exit(1)

    print("Neutorch has completed optimization.")
    return opt_model
