import os
import ctypes
from ctypes import POINTER, c_char_p, c_void_p, c_uint32, c_float, c_bool, c_size_t
import numpy as np

# Load the main shared library
# Dynamically resolve the path to libneu_vss.so
current_dir = os.path.dirname(os.path.abspath(__file__))
lib_path = os.path.join(current_dir, "lib", "libneu_vss.so")

if os.name == "nt":  # Windows
    lib_path = os.path.join(current_dir, "lib", "neu_vss.dll")

try:
    vss = ctypes.CDLL(lib_path)  # Adjust the path if necessary
    print("Library loaded successfully.")
except OSError as e:
    print(f"Failed to load the library: {e}")


# Define the return and argument types for each function
vss.NeuVss_Create.argtypes = [c_char_p]
vss.NeuVss_Create.restype = c_void_p

vss.NeuVss_Destroy.argtypes = [c_void_p]
vss.NeuVss_Destroy.restype = None

vss.NeuVss_GetVersion.restype = c_char_p

vss.NeuVss_ConvertDb.argtypes = [c_uint32, c_char_p, c_char_p]
vss.NeuVss_ConvertDb.restype = c_bool

vss.NeuVss_GetAvailableDevices.argtypes = [POINTER(c_size_t)]
vss.NeuVss_GetAvailableDevices.restype = POINTER(c_char_p)

vss.NeuVss_FreeAvailableDevices.argtypes = [ctypes.POINTER(ctypes.c_char_p), ctypes.c_size_t]
vss.NeuVss_FreeAvailableDevices.restype = None

vss.NeuVss_Initialize.argtypes = [c_void_p, c_uint32, c_char_p, c_float]
vss.NeuVss_Initialize.restype = c_bool

vss.NeuVss_Run.argtypes = [c_void_p, ctypes.c_void_p, c_uint32, ctypes.c_void_p, c_uint32]
vss.NeuVss_Run.restype = c_bool


class PyNeuVssCalculator:
    """
    Python wrapper for the NeuVssCalculator with naming conventions consistent with Pybind11.
    """

    def __init__(self):
        self.handle = None

    @staticmethod
    def get_version():
        return vss.NeuVss_GetVersion().decode('utf-8')

    @staticmethod
    def get_available_device():
        count = c_size_t()
        devices = vss.NeuVss_GetAvailableDevices(ctypes.byref(count))

        if not devices:
            return []

        device_list = []
        for i in range(count.value):
            try:
                device_list.append(devices[i].decode('utf-8'))
            except UnicodeDecodeError as e:
                vss.NeuVss_FreeAvailableDevices(devices, count.value)
                raise RuntimeError(f"Failed to decode device name at index {i}. Error: {e}")

        vss.NeuVss_FreeAvailableDevices(devices, count.value)

        return device_list

    @staticmethod
    def convert_db(row_size, db_bin_path, weight_bin_dir):
        return vss.NeuVss_ConvertDb(row_size, db_bin_path.encode('utf-8'), weight_bin_dir.encode('utf-8'))

    def bind_device(self, device_id):
        self.handle = vss.NeuVss_Create(device_id.encode('utf-8'))
        if not self.handle:
            raise RuntimeError(f"Failed to bind device with ID: {device_id}")
        return True

    def initialize(self, input_dim, table_dir, q_scale):
        if not self.handle:
            raise RuntimeError("Device not bound. Call bind_device first.")
        success = vss.NeuVss_Initialize(self.handle, input_dim, table_dir.encode('utf-8'), q_scale)
        if not success:
            raise RuntimeError(f"Failed to initialize with input_dim={input_dim}, table_dir={table_dir}, q_scale={q_scale}")
        return success

    def run(self, input_data, output_data):
        if not isinstance(input_data, np.ndarray) or not isinstance(output_data, np.ndarray):
            raise TypeError("Input and output data must be NumPy arrays.")
        if not self.handle:
            raise RuntimeError("Device not bound. Call bind_device first.")

        input_buffer = (ctypes.c_uint8 * len(input_data))(*input_data)
        output_size = output_data.size
        output_buffer = (ctypes.c_uint8 * output_size)()

        success = vss.NeuVss_Run(self.handle, ctypes.byref(input_buffer), len(input_data),
                                 ctypes.byref(output_buffer), output_size)
        if success:
            output_data[:] = np.frombuffer(output_buffer, dtype=np.uint8)
        return success
