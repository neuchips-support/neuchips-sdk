import torch
import torch.nn as nn
from neutorch.conversion.passes.qkv_linear_merge_pass import (
    QKV_MERGE_SUPPORTED_TRANSFORMERS_VERSION,
)


def low_rank_decomposition(
    W: torch.Tensor, rank: int
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    Perform a low-rank decomposition W ≈ A * B using truncated SVD.

    Args:
        W   (torch.Tensor): [out_features, in_features] weight matrix.
        rank        (int):  Desired rank (must be <= min(out_features, in_features)).

    Returns:
        A, B (torch.Tensor, torch.Tensor)
          - A of shape [out_features, rank]
          - B of shape [rank, in_features]
    """
    if rank > min(W.shape):
        raise ValueError(f"Rank={rank} is larger than min(W.shape)={min(W.shape)}")

    # Compute the SVD
    # See https://pytorch.org/docs/stable/generated/torch.linalg.svd.html
    with torch.no_grad():
        U, S, Vh = torch.linalg.svd(W, full_matrices=False)
        # shapes:
        # U:  [out_features, min(out_features, in_features)]
        # S:  [min(out_features, in_features)]
        # Vh: [min(out_features, in_features), in_features]

        # Truncate to rank
        U_r = U[:, :rank]  # [out_features, rank]
        S_r = S[:rank]  # [rank]
        Vh_r = Vh[:rank, :]  # [rank, in_features]

        # Build A and B
        # W ≈ (U_r * diag(S_r)) @ Vh_r
        A = U_r @ torch.diag(S_r)  # [out_features, rank]
        B = Vh_r  # [rank, in_features]

        return A, B


def replace_linear_with_low_rank(linear_op: nn.Linear, rank: int) -> nn.Sequential:
    """
    Decomposes an existing nn.Linear operator's weight into two smaller linear ops.

    Args:
        linear_op (nn.Linear): The original linear op (with weight.shape=[out_features, in_features]).
        rank         (int)   : Desired low-rank dimension.

    Returns:
        low_rank_seq (nn.Sequential): A sequence of two linear ops that approximate the original.
    """
    # Decompose the original weight
    W = linear_op.weight.data.to(torch.float32)  # shape [out_features, in_features]
    A, B = low_rank_decomposition(W, rank=rank)

    in_features = linear_op.in_features
    out_features = linear_op.out_features

    dtype = linear_op.weight.dtype
    has_bias = True if linear_op.bias is not None else False
    # Create a two linear ops module:
    #    op1: (in_features -> rank)   [no bias]
    #    op2: (rank -> out_features)  [with bias if any]
    low_rank_seq = nn.Sequential(
        nn.Linear(in_features, rank, bias=False).to(dtype),
        nn.Linear(rank, out_features, bias=has_bias).to(dtype),
    )

    # The first op's weight is B, shape [rank, in_features].
    low_rank_seq[0].weight.data = B.to(dtype)
    # The second op's weight is A, shape [out_features, rank].
    low_rank_seq[1].weight.data = A.to(dtype)

    # The second op is the "output" op, so we keep the same bias as the old linear
    if has_bias:
        low_rank_seq[1].bias.data = linear_op.bias.data

    return low_rank_seq


def get_rank(dim: int, low_rank_ratio: float, rounding: int) -> int:
    rounded = ((low_rank_ratio * dim + rounding - 1) // rounding) * rounding
    return int(rounded)


def low_rank_decomposition_pass(
    model: torch.nn.Module, low_rank_ratio: float
) -> torch.nn.Module:
    def try_decompose_qkv(m: torch.nn.Module):
        for n, module in m.named_children():
            if type(module) == torch.nn.Linear and n in [
                "qkv_proj",
                # "gate_proj",
                # "up_proj",
                # "down_proj",
            ]:
                # Rounding to 64 to align with weight shape HW constraint
                rank = get_rank(
                    min(module.in_features, module.out_features), low_rank_ratio, 64
                )
                low_rank_seq = replace_linear_with_low_rank(module, rank=rank)
                setattr(m, n, low_rank_seq)
            try_decompose_qkv(module)

    from transformers import __version__ as transformers_version

    if transformers_version not in QKV_MERGE_SUPPORTED_TRANSFORMERS_VERSION:
        print(
            f"Warning: Unsupported transformers version {transformers_version}. Low rank decomposition may not work as expected."
        )
        return model
    try_decompose_qkv(model)
    return model
