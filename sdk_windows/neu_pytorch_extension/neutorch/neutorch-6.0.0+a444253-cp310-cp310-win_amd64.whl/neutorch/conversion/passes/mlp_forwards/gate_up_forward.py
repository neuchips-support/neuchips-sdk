def gate_up_forward(self, x):
    gate_up_states = self.gate_up_proj(x)
    gate_states, up_states = gate_up_states.split(
        [self.intermediate_size, self.intermediate_size], dim=-1
    )
    down_proj = self.down_proj(self.act_fn(gate_states) * up_states)
    return down_proj
