#
# NEUCHIPS CONFIDENTIAL
#
# Copyright (C) 2018-2022 NEUCHIPS Corp.
# All Rights Reserved.
# Author: Ethan Chen <ethan_chen@neuchips.ai>
#
# The information and source code contained herein is the exclusive property
# of NEUCHIPS CORPORATION and may not be disclosed, examined or reproduced
# in whole or in part without explicit written authorization from the company.
#

import torch
from torch import Tensor
import torch.nn as nn
import torch.fx.experimental.optimization as optimization
import torch.fx as fx
import copy
from neutorch._C import MultiDeviceN3KPytorchFacade

_SUPPORTED_MODELS = [
    "LLaMAForCausalLM",
    "LlamaForCausalLM",
    "MistralForCausalLM",
    "PhiForCausalLM",
    "AutoModelForCausalLM",
    "Phi3ForCausalLM",
    "Gemma2ForCausalLM",
]


class neu_linear(torch.nn.Module):
    def __init__(self, weight: Tensor, bias) -> None:
        super().__init__()
        self.facade = MultiDeviceN3KPytorchFacade.get_instance()
        self.op_id = self.facade.register_matmul_with_weight(weight.detach().t())
        self.bias = bias
        self.weight = weight

    def forward(self, input: Tensor) -> Tensor:
        result = self.facade.execute_op(self.op_id, input)
        if self.bias is not None:
            result = result + self.bias
        return result


def is_transfomer_model(model):
    name = model.__class__.__module__
    return name.startswith("transformers.models.")


def is_supported_model(model):
    return model.__class__.__name__ in _SUPPORTED_MODELS


def linear_conversion(
    model_: nn.Module,
    usage_pattern="general",
    weight_dtype=None,
    inplace=False,
    config_dir="",
) -> nn.Module:
    # replace torch linear with neuchips linear for inference
    if not inplace:
        model = copy.deepcopy(model_)
    else:
        model = model_

    if not is_supported_model(model):
        return model

    def replace_linear(model, model_):
        for (n, module), (n_, module_) in zip(
            model.named_children(), model_.named_children()
        ):
            if len(list(module.children())) > 0:
                # compound module, go inside it
                replace_linear(module, module_)

            if isinstance(module, torch.nn.Linear):
                # Reuse weight when not inPlace but need fallback.
                _neu_linear = neu_linear(weight=module_.weight, bias=module.bias)
                setattr(model, n, _neu_linear)

    for layer, layer_ in zip(model.model.layers, model_.model.layers):
        replace_linear(layer, layer_)

    if hasattr(model, "lm_head") and isinstance(model.lm_head, torch.nn.Linear):
        _neu_linear = neu_linear(weight=model.lm_head.weight, bias=model.lm_head.bias)
        setattr(model, "lm_head", _neu_linear)

    facade = MultiDeviceN3KPytorchFacade.get_instance()

    # For general use, set the max batch size to 256.
    max_batch_size = 256
    if usage_pattern == "long":
        max_batch_size = 512

    try:
        if config_dir:
            facade.load(config_dir)
            facade.execute_code_generation(
                directory=config_dir, max_batch_size=max_batch_size
            )
        else:
            facade.execute_code_generation(max_batch_size=max_batch_size)
    except RuntimeError as e:
        print(f"Error: {e}")
        return None

    return model


def linear_conversion_fx(
    model: nn.Module, weight_dtype=None, inplace=False
) -> nn.Module:
    # replace torch linear with neuchips linear for inference
    if not inplace:
        model = copy.deepcopy(model)

    fx_model = fx.symbolic_trace(model)

    modules = dict(fx_model.named_modules())

    for node in fx_model.graph.nodes:
        if node.op != "call_module":
            continue
        if type(modules[node.target]) is nn.Linear:
            linear = modules[node.target]
            _neu_linear = neu_linear(
                in_features=linear.in_features,
                out_features=linear.out_features,
                weight=linear.weight,
                bias=linear.bias,
            )
            optimization.replace_node_module(node, modules, _neu_linear)
    fx_model.graph.lint()
    fx_model.recompile()

    facade = MultiDeviceN3KPytorchFacade.get_instance()
    facade.execute_code_generation()

    return fx_model


def linear_conversion_hf(
    model: nn.Module, weight_dtype=None, inplace=False
) -> nn.Module:  # not supported yet
    if not inplace:
        model = copy.deepcopy(model)

    try:
        from transformers.utils.fx import symbolic_trace as hf_symbolic_trace
    except ImportError:
        import warnings

        # fx are not exposed in transformers.utils
        warnings.warn(
            "failed to import transformers symbolic_trace, cannnot convert linear"
        )
    if is_transfomer_model(model):
        try:
            fx_model: fx.GraphModule = hf_symbolic_trace(model, disable_check=True)
            # convert linear to neuchips linear here
            return model
        except BaseException:
            import warnings

            warnings.warn(
                "failed to symbolic trace model with transformers symbolic_trace, cannnot convert linear"
            )
    else:
        return linear_conversion_fx(model, inplace=True)
